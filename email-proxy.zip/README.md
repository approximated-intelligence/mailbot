# email-proxy

Personal email automation via IMAP IDLE.

## Why

Email clients are bloated. Server-side rules are limited. I wanted:
- Auto-reply + forward for work emails (with language detection)
- Snarky auto-delete for obnoxious senders  
- URL-to-readable-email proxy (send yourself a link, get back clean HTML or Kindle-ready text)
- Sort newsletters and CC'd emails automatically

## How

Daemon monitors inbox using IMAP IDLE. Rules are composable S-expressions:

```python
Match(AllOf(Froms("@work.com"), Not(Tos("archive@"))))
```

Handlers chain: `WorkEmail → SetFlags → Move → Expunge`

## Setup

1. Copy `config_data.py`, fill in your addresses
2. `python runloop.py` (or `runonce.py` for single pass)
3. Password via `EMAIL_PASSWORD` env var, `--password=x`, or prompt

## Proxy

Email a URL to `txt+proxy@yourdomain.com`. Options in address:
- `txt` — convert to plain text
- `bleach` — sanitize HTML
- `images` — inline images
- `kindle` — send to Kindle

---

*No dependencies on cloud services. Your rules, your server.*
