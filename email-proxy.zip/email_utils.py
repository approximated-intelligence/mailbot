# -*- coding: utf-8 -*-
"""
Email utilities: parsing, construction, language detection, SMTP sending.
"""

import os
import re
import email
import email.mime.text
import email.mime.multipart
import email.mime.image
import email.mime.application
import email.mime.message
import email.header
import email.utils
import smtplib

import html_utils


# ============================================================================
# Message deduplication
# ============================================================================

def should_process_message(message_id, seen_ids):
    """
    Check if message should be processed based on Message-ID deduplication.
    
    Args:
        message_id: The Message-ID header value
        seen_ids: Set of already processed message IDs
    
    Returns:
        (should_process, updated_seen_ids) tuple
    """
    if message_id in seen_ids:
        return False, seen_ids
    return True, seen_ids | {message_id}


# ============================================================================
# Language detection
# ============================================================================

def detect_language(email_message, available_languages, default="en"):
    """
    Detect language from email headers and body.
    
    Checks in order:
    1. Content-Language header
    2. Subject for language indicators
    
    Args:
        email_message: Parsed email message
        available_languages: List/keys of supported language codes
        default: Fallback language code
    
    Returns:
        Language code (e.g., "de", "en")
    """
    content_lang = email_message.get('Content-Language', '')
    for lang in available_languages:
        if lang in content_lang.lower():
            return lang
    
    subject = email_message.get('Subject', '').lower()
    
    if any(word in subject for word in ['betreff', 'betrifft', 'anfrage', 'sehr geehrte']):
        if 'de' in available_languages:
            return 'de'
    
    return default


# ============================================================================
# Email construction
# ============================================================================

def create_email_message(subject, from_addr, to_addr, in_reply_to=None, 
                         reply_to=None, subject_prefix=None, message_id_domain=None):
    """
    Create email message with standard headers.
    
    Args:
        subject: Email subject
        from_addr: Sender address
        to_addr: Recipient address
        in_reply_to: Optional Message-ID being replied to/forwarded
        reply_to: Optional Reply-To address
        subject_prefix: Optional prefix ('Re:', 'Fwd:', etc.)
        message_id_domain: Optional domain for Message-ID generation
    
    Returns:
        MIMEMultipart message object with headers set
    """
    msg_subject = f'{subject_prefix} {subject}' if subject_prefix else subject
    
    msg = email.mime.multipart.MIMEMultipart()
    msg['Subject'] = msg_subject
    msg['From'] = from_addr
    msg['To'] = to_addr
    
    if reply_to:
        msg['Reply-To'] = reply_to
    
    msg['Message-ID'] = (email.utils.make_msgid(message_id_domain) 
                         if message_id_domain 
                         else email.utils.make_msgid())
    msg['Date'] = email.utils.formatdate()
    
    if in_reply_to:
        msg['In-Reply-To'] = in_reply_to
        msg['References'] = in_reply_to
    
    return msg


def create_reply_message(subject, from_addr, to_addr, in_reply_to, body, 
                        reply_to=None, message_id_domain=None):
    """
    Create reply message with text body.
    
    Returns:
        Complete reply message
    """
    msg = create_email_message(
        subject=subject,
        from_addr=from_addr,
        to_addr=to_addr,
        in_reply_to=in_reply_to,
        reply_to=reply_to,
        subject_prefix='Re:',
        message_id_domain=message_id_domain
    )
    msg.attach(email.mime.text.MIMEText(body, 'plain', 'utf-8'))
    return msg


def create_forward_message(subject, from_addr, to_addr, in_reply_to, 
                           forward_note, original_message, reply_to=None):
    """
    Create forward message with original attached.
    
    Returns:
        Complete forward message
    """
    msg = create_email_message(
        subject=subject,
        from_addr=from_addr,
        to_addr=to_addr,
        in_reply_to=in_reply_to,
        reply_to=reply_to,
        subject_prefix='Fwd:'
    )
    msg.attach(email.mime.text.MIMEText(forward_note, 'plain', 'utf-8'))
    msg.attach(email.mime.message.MIMEMessage(original_message))
    return msg


def build_mime_parts(content, mimetype, subtype, filename, subject, charset='utf-8', as_inline=True, infotext=None):
    """
    Build list of MIME parts for content.
    
    Args:
        content: The content (string for text, bytes for binary)
        mimetype: Full MIME type string
        subtype: MIME subtype (e.g., 'plain', 'html', 'pdf')
        filename: Filename for attachments
        subject: Subject for filename prefix
        charset: Character set for text content
        as_inline: Include content inline vs attachment only
        infotext: Optional info text to prepend
    
    Returns:
        List of MIME parts
    """
    parts = []
    
    if infotext:
        parts.append(email.mime.text.MIMEText(infotext, 'plain', 'utf-8'))
    
    if mimetype.startswith('text/'):
        part = email.mime.text.MIMEText(content, subtype, charset)
        parts.append(part)
        
        if not as_inline:
            attachment = email.mime.text.MIMEText(content, subtype, charset)
            attachment.add_header('Content-Disposition', 'attachment', filename=f"{subject}: {filename}")
            parts.append(attachment)
            
    elif mimetype.startswith('image/'):
        part = email.mime.image.MIMEImage(content, subtype)
        part.add_header('Content-Disposition', 'attachment', filename=f"{subject}: {filename}")
        parts.append(part)
        
    elif mimetype.startswith('application/'):
        part = email.mime.application.MIMEApplication(content, subtype)
        if 'pdf' in subtype and not filename.endswith('.pdf'):
            filename = filename + '.pdf'
        part.add_header('Content-Disposition', 'attachment', filename=f"{subject}: {filename}")
        parts.append(part)
        
    else:
        part = email.mime.application.MIMEApplication(content, subtype)
        part.add_header('Content-Disposition', 'attachment', filename=f"{subject}: {filename}")
        parts.append(part)
    
    return parts


# ============================================================================
# SMTP sending
# ============================================================================

def send_via_smtp(options, from_addr, to_addr, message):
    """
    Send message via SMTP with connection handling.
    
    Args:
        options: Dict with smtp_server, smtp_user, smtp_pass
        from_addr: Sender address
        to_addr: Recipient address (or list)
        message: Message object or string
    """
    smtp_connection = smtplib.SMTP_SSL(options['smtp_server'])
    smtp_connection.login(options['smtp_user'], options['smtp_pass'])
    try:
        smtp_connection.sendmail(
            from_addr, 
            to_addr, 
            message if isinstance(message, str) else message.as_string()
        )
    finally:
        smtp_connection.quit()


# ============================================================================
# Email parsing
# ============================================================================

def _decode_part(part):
    """
    Decode a single MIME part to string.
    
    Args:
        part: MIME part
    
    Returns:
        Decoded string or None on failure
    """
    try:
        payload = part.get_payload(decode=True)
        if payload is None:
            return None
        
        charset = part.get_content_charset() or 'utf-8'
        
        for encoding in [charset, 'utf-8', 'iso-8859-1']:
            try:
                return payload.decode(encoding)
            except (UnicodeDecodeError, LookupError):
                continue
        
        return payload.decode('utf-8', errors='replace')
    except Exception:
        return None


def extract_urls_from_email(msg):
    """
    Extract deduplicated URLs from all text content in email.
    Converts HTML parts to text to extract links.
    
    Args:
        msg: Parsed email message
    
    Returns:
        Set of URLs found in the message
    """
    urls = set()
    converter = html_utils.make_html2text_converter()
    
    url_pattern = re.compile(
        r'http[s]?://(?:[a-zA-Z]|[0-9]|[~$-_@.&+|]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    )
    
    parts = msg.iter_parts() if msg.is_multipart() else [msg]
    
    for part in parts:
        decoded = _decode_part(part)
        if not decoded:
            continue
        
        content_type = part.get_content_type()
        
        if content_type == 'text/html':
            text = converter.handle(decoded)
        else:
            text = decoded
        
        found = url_pattern.findall(text)
        urls.update(found)
    
    return urls


def get_decoded_email_body(msg):
    """
    Decode email body.
    Extract text/plain, fallback to text/html.
    
    Args:
        msg: Parsed email message
    
    Returns:
        Message body as unicode string
    """
    if msg.is_multipart():
        text_part = None
        html_part = None
        
        for part in msg.iter_parts():
            content_type = part.get_content_type()
            
            if content_type == 'text/plain' and text_part is None:
                text_part = _decode_part(part)
            elif content_type == 'text/html' and html_part is None:
                html_part = _decode_part(part)
        
        return (text_part or html_part or '').strip()
    else:
        return (_decode_part(msg) or '').strip()
