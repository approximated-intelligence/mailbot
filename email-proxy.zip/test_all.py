# -*- coding: utf-8 -*-
"""
Unit tests for email proxy system.
Run with: python -m pytest test_all.py -v

Tests focus on WHAT functions do (behavior), not HOW they do it (implementation).
"""

import unittest
from parsequery import Match, From, To, Cc, Subject, AnyOf, AllOf, Not, parseQuery
from parsequery import Froms, Tos, Ccs, SubjectPatterns


# ============================================================================
# parsequery.py tests
# ============================================================================

class TestFieldBuilders(unittest.TestCase):
    """Tests for field builder functions"""
    
    def test_from_single_returns_list(self):
        result = From("user@domain")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
    
    def test_from_multiple_returns_list_per_address(self):
        result = From("a@x", "b@x", "c@x")
        self.assertEqual(len(result), 3)
    
    def test_to_single_returns_list(self):
        result = To("user@domain")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
    
    def test_cc_single_returns_list(self):
        result = Cc("user@domain")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
    
    def test_subject_single_returns_list(self):
        result = Subject("test")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
    
    def test_field_thunks_produce_imap_syntax(self):
        from_thunk = From("user@domain")[0]
        self.assertEqual(from_thunk(), '(FROM "user@domain")')
        
        to_thunk = To("user@domain")[0]
        self.assertEqual(to_thunk(), '(TO "user@domain")')
        
        cc_thunk = Cc("user@domain")[0]
        self.assertEqual(cc_thunk(), '(CC "user@domain")')
        
        subject_thunk = Subject("test")[0]
        self.assertEqual(subject_thunk(), '(SUBJECT "test")')


class TestPluralAliases(unittest.TestCase):
    """Tests for plural aliases"""
    
    def test_froms_is_alias_for_from(self):
        self.assertIs(Froms, From)
    
    def test_tos_is_alias_for_to(self):
        self.assertIs(Tos, To)
    
    def test_ccs_is_alias_for_cc(self):
        self.assertIs(Ccs, Cc)
    
    def test_subjectpatterns_is_alias_for_subject(self):
        self.assertIs(SubjectPatterns, Subject)
    
    def test_froms_produces_same_result(self):
        self.assertEqual(Match(AnyOf(From("a@x"))), Match(AnyOf(Froms("a@x"))))
    
    def test_tos_produces_same_result(self):
        self.assertEqual(Match(AnyOf(To("a@x"))), Match(AnyOf(Tos("a@x"))))


class TestCombinators(unittest.TestCase):
    """Tests for AnyOf, AllOf, Not combinators"""
    
    def test_anyof_single_field_single_value(self):
        result = Match(AnyOf(From("user@domain")))
        self.assertEqual(result, '(FROM "user@domain")')
    
    def test_anyof_single_field_multiple_values(self):
        result = Match(AnyOf(From("a@x", "b@x")))
        self.assertEqual(result, '(OR (FROM "a@x") (FROM "b@x"))')
    
    def test_anyof_single_field_three_values(self):
        result = Match(AnyOf(From("a@x", "b@x", "c@x")))
        self.assertEqual(result, '(OR (OR (FROM "a@x") (FROM "b@x")) (FROM "c@x"))')
    
    def test_allof_single_field_single_value(self):
        result = Match(AllOf(From("user@domain")))
        self.assertEqual(result, '(FROM "user@domain")')
    
    def test_allof_single_field_multiple_values(self):
        result = Match(AllOf(From("a@x", "b@x")))
        self.assertEqual(result, '((FROM "a@x") (FROM "b@x"))')
    
    def test_allof_multiple_fields(self):
        result = Match(AllOf(From("sender@x"), To("recipient@y")))
        self.assertEqual(result, '((FROM "sender@x") (TO "recipient@y"))')
    
    def test_not_single_value(self):
        result = Match(Not(From("spam@x")))
        self.assertEqual(result, '(NOT (FROM "spam@x"))')
    
    def test_not_anyof(self):
        result = Match(Not(AnyOf(To("@"), Cc("@"))))
        self.assertEqual(result, '(NOT (OR (TO "@") (CC "@")))')


class TestNestedExpressions(unittest.TestCase):
    """Tests for complex nested query expressions"""
    
    def test_allof_with_nested_anyof(self):
        result = Match(AllOf(From("@mydomain"), AnyOf(To("a@x"), To("b@x"))))
        self.assertIn('FROM "@mydomain"', result)
        self.assertIn('OR', result)
        self.assertIn('TO "a@x"', result)
        self.assertIn('TO "b@x"', result)
    
    def test_anyof_with_nested_allof(self):
        result = Match(AnyOf(AllOf(From("a@x"), To("b@x")), From("c@x")))
        self.assertIn('OR', result)
        self.assertIn('FROM "a@x"', result)
        self.assertIn('TO "b@x"', result)
        self.assertIn('FROM "c@x"', result)
    
    def test_complex_self_email_query(self):
        """Test the 'emails from self without explicit recipients' pattern"""
        mydomain = "@mydomain"
        result = Match(AllOf(
            Froms(mydomain), 
            AnyOf(Tos(mydomain), Not(AnyOf(Tos("@"), Ccs("@"))))
        ))
        self.assertIn('FROM "@mydomain"', result)
        self.assertIn('TO "@mydomain"', result)
        self.assertIn('NOT', result)
        self.assertIn('CC "@"', result)
    
    def test_deeply_nested(self):
        result = Match(AllOf(
            From("a@x"),
            AnyOf(
                AllOf(To("b@x"), Cc("c@x")),
                Not(From("d@x"))
            )
        ))
        self.assertIn('FROM "a@x"', result)
        self.assertIn('TO "b@x"', result)
        self.assertIn('CC "c@x"', result)
        self.assertIn('NOT', result)
        self.assertIn('FROM "d@x"', result)


class TestMatchFunction(unittest.TestCase):
    """Tests for the Match/parseQuery function"""
    
    def test_match_is_alias_for_parsequery(self):
        self.assertIs(Match, parseQuery)
    
    def test_match_single_from(self):
        result = Match(From("user@domain"))
        self.assertEqual(result, '(FROM "user@domain")')
    
    def test_match_multiple_from_implicit_or(self):
        """Multiple From values without combinator should OR them"""
        result = Match(From("a@x", "b@x"))
        self.assertEqual(result, '(OR (FROM "a@x") (FROM "b@x"))')
    
    def test_match_empty_string_preserved(self):
        result = Match(From(""))
        self.assertEqual(result, '(FROM "")')


class TestConfigQueriesPatterns(unittest.TestCase):
    """Tests matching actual patterns from config_queries.py"""
    
    def test_work_senders_pattern(self):
        work_senders = ["arbeit@", "@uni"]
        result = Match(AnyOf(Froms(*work_senders)))
        self.assertEqual(result, '(OR (FROM "arbeit@") (FROM "@uni"))')
    
    def test_newsletters_pattern(self):
        newsletters = ["civey@", "academicpositions@"]
        result = Match(AnyOf(Tos(*newsletters)))
        self.assertEqual(result, '(OR (TO "civey@") (TO "academicpositions@"))')
    
    def test_proxy_pattern(self):
        mydomain = "@mydomain"
        proxy_to = "be1919cc@mydomain"
        result = Match(AllOf(Froms(mydomain), Tos(proxy_to)))
        self.assertIn('(FROM "@mydomain")', result)
        self.assertIn('(TO "be1919cc@mydomain")', result)
    
    def test_self_without_recipients_pattern(self):
        mydomain = "@mydomain"
        result = Match(AllOf(
            Froms(mydomain), 
            AnyOf(Tos(mydomain), Not(AnyOf(Tos("@"), Ccs("@"))))
        ))
        self.assertIn('FROM "@mydomain"', result)
        self.assertIn('NOT', result)
    
    def test_single_sender_pattern(self):
        mydomain = "@mydomain"
        result = Match(AnyOf(Froms(mydomain)))
        self.assertEqual(result, '(FROM "@mydomain")')
    
    def test_single_element_list_expansion(self):
        """Ensure *list expansion works with single elements"""
        emails = ["test@example.com"]
        result = Match(AnyOf(Tos(*emails)))
        self.assertEqual(result, '(TO "test@example.com")')


class TestIMAPSyntaxValidity(unittest.TestCase):
    """Tests that generated queries are valid IMAP SEARCH syntax"""
    
    def test_no_unmatched_parens(self):
        queries = [
            Match(AnyOf(Froms("a@x", "b@x", "c@x"))),
            Match(AllOf(Froms("a@x"), Tos("b@x"), Ccs("c@x"))),
            Match(AllOf(Froms("@mydomain"), AnyOf(Tos("@mydomain"), Not(AnyOf(Tos("@"), Ccs("@")))))),
        ]
        for query in queries:
            open_count = query.count('(')
            close_count = query.count(')')
            self.assertEqual(open_count, close_count, f"Unmatched parens in: {query}")
    
    def test_valid_imap_keywords(self):
        """Ensure only valid IMAP SEARCH keywords are used"""
        valid_keywords = {'FROM', 'TO', 'CC', 'SUBJECT', 'OR', 'NOT'}
        
        queries = [
            Match(Froms("a@x")),
            Match(Tos("a@x")),
            Match(Ccs("a@x")),
            Match(SubjectPatterns("test")),
            Match(AnyOf(Froms("a@x"), Tos("b@x"))),
            Match(Not(Froms("a@x"))),
        ]
        
        for query in queries:
            import re
            keywords = re.findall(r'\(([A-Z]+)', query)
            for kw in keywords:
                self.assertIn(kw, valid_keywords, f"Invalid keyword {kw} in: {query}")
    
    def test_quoted_addresses(self):
        """Ensure addresses are properly quoted"""
        queries = [
            Match(Froms("user@domain.com")),
            Match(Froms("user with spaces@domain.com")),
            Match(Froms("@partial")),
        ]
        for query in queries:
            self.assertIn('"', query)


class TestEdgeCases(unittest.TestCase):
    """Tests for edge cases and boundary conditions"""
    
    def test_special_characters_in_address(self):
        result = Match(Froms("user+tag@domain.com"))
        self.assertEqual(result, '(FROM "user+tag@domain.com")')
    
    def test_partial_domain_match(self):
        result = Match(Froms("@gmail.com"))
        self.assertEqual(result, '(FROM "@gmail.com")')
    
    def test_partial_local_match(self):
        result = Match(Tos("newsletter@"))
        self.assertEqual(result, '(TO "newsletter@")')
    
    def test_subject_with_spaces(self):
        result = Match(SubjectPatterns("Re: Your inquiry"))
        self.assertEqual(result, '(SUBJECT "Re: Your inquiry")')
    
    def test_many_or_values(self):
        addresses = [f"user{i}@domain.com" for i in range(5)]
        result = Match(AnyOf(Froms(*addresses)))
        self.assertEqual(result.count('OR'), 4)
        for addr in addresses:
            self.assertIn(addr, result)


# ============================================================================
# email_utils.py tests
# ============================================================================

class TestShouldProcessMessage(unittest.TestCase):
    """Tests for message deduplication"""
    
    def test_new_message_should_process(self):
        from email_utils import should_process_message
        seen = set()
        should, new_seen = should_process_message("msg1@domain", seen)
        self.assertTrue(should)
        self.assertIn("msg1@domain", new_seen)
    
    def test_seen_message_should_not_process(self):
        from email_utils import should_process_message
        seen = {"msg1@domain"}
        should, new_seen = should_process_message("msg1@domain", seen)
        self.assertFalse(should)
    
    def test_original_set_unchanged(self):
        from email_utils import should_process_message
        seen = set()
        _, new_seen = should_process_message("msg1@domain", seen)
        self.assertEqual(len(seen), 0)
        self.assertEqual(len(new_seen), 1)


class TestDetectLanguage(unittest.TestCase):
    """Tests for language detection"""
    
    def test_detect_from_content_language_header(self):
        from email_utils import detect_language
        from email.message import EmailMessage
        
        msg = EmailMessage()
        msg['Content-Language'] = 'de'
        
        result = detect_language(msg, ['en', 'de'], default='en')
        self.assertEqual(result, 'de')
    
    def test_detect_from_german_subject(self):
        from email_utils import detect_language
        from email.message import EmailMessage
        
        msg = EmailMessage()
        msg['Subject'] = 'Betreff: Ihre Anfrage'
        
        result = detect_language(msg, ['en', 'de'], default='en')
        self.assertEqual(result, 'de')
    
    def test_default_when_no_indicators(self):
        from email_utils import detect_language
        from email.message import EmailMessage
        
        msg = EmailMessage()
        msg['Subject'] = 'Hello there'
        
        result = detect_language(msg, ['en', 'de'], default='en')
        self.assertEqual(result, 'en')


class TestCreateEmailMessage(unittest.TestCase):
    """Tests for email message creation - verifies required headers are set"""
    
    def test_required_headers_present(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test Subject",
            from_addr="sender@example.com",
            to_addr="recipient@example.com"
        )
        self.assertEqual(msg['Subject'], "Test Subject")
        self.assertEqual(msg['From'], "sender@example.com")
        self.assertEqual(msg['To'], "recipient@example.com")
        self.assertIsNotNone(msg['Message-ID'])
        self.assertIsNotNone(msg['Date'])
    
    def test_subject_prefix_applied(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Original",
            from_addr="from@x",
            to_addr="to@x",
            subject_prefix="Re:"
        )
        self.assertEqual(msg['Subject'], "Re: Original")
    
    def test_reply_to_set_when_provided(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            reply_to="reply@x"
        )
        self.assertEqual(msg['Reply-To'], "reply@x")
    
    def test_threading_headers_set_for_reply(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<original@example.com>"
        )
        self.assertEqual(msg['In-Reply-To'], "<original@example.com>")
        self.assertEqual(msg['References'], "<original@example.com>")


class TestCreateReplyMessage(unittest.TestCase):
    """Tests for reply message creation"""
    
    def test_reply_has_re_prefix(self):
        from email_utils import create_reply_message
        msg = create_reply_message(
            subject="Original",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<orig@x>",
            body="Reply body"
        )
        self.assertEqual(msg['Subject'], "Re: Original")
    
    def test_reply_can_be_serialized(self):
        from email_utils import create_reply_message
        msg = create_reply_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<orig@x>",
            body="This is the reply body"
        )
        # Should serialize without error
        serialized = msg.as_string()
        self.assertIsInstance(serialized, str)
        self.assertGreater(len(serialized), 0)


class TestCreateForwardMessage(unittest.TestCase):
    """Tests for forward message creation"""
    
    def test_forward_has_fwd_prefix(self):
        from email_utils import create_forward_message
        from email.message import EmailMessage
        
        original = EmailMessage()
        original['Subject'] = "Original"
        
        msg = create_forward_message(
            subject="Original",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<orig@x>",
            forward_note="Forwarding this",
            original_message=original
        )
        self.assertEqual(msg['Subject'], "Fwd: Original")
    
    def test_forward_can_be_serialized(self):
        from email_utils import create_forward_message
        from email.message import EmailMessage
        
        original = EmailMessage()
        original.set_content("Original content")
        
        msg = create_forward_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<orig@x>",
            forward_note="See below",
            original_message=original
        )
        # Should serialize without error
        serialized = msg.as_string()
        self.assertIsInstance(serialized, str)
        self.assertGreater(len(serialized), 0)


# ============================================================================
# http_utils.py tests
# ============================================================================

class TestGetFilenameFromHeadersOrUrl(unittest.TestCase):
    """Tests for filename extraction"""
    
    def test_extracts_from_content_disposition(self):
        from http_utils import get_filename_from_headers_or_url
        
        headers = {'content-disposition': 'attachment; filename="report.pdf"'}
        result = get_filename_from_headers_or_url(headers, "http://example.com/other")
        self.assertEqual(result, "report.pdf")
    
    def test_falls_back_to_url(self):
        from http_utils import get_filename_from_headers_or_url
        
        headers = {}
        result = get_filename_from_headers_or_url(headers, "http://example.com/path/file.txt")
        self.assertIn("file", result)
    
    def test_returns_default_on_empty(self):
        from http_utils import get_filename_from_headers_or_url
        
        headers = {}
        result = get_filename_from_headers_or_url(headers, "")
        self.assertEqual(result, "download")


# ============================================================================
# imap_utils.py tests
# ============================================================================

class TestGetCredential(unittest.TestCase):
    """Tests for credential retrieval from different sources"""
    
    def test_reads_from_environment(self):
        import os
        from imap_utils import get_credential
        
        os.environ['TEST_CRED_ENV'] = 'secret_from_env'
        try:
            result = get_credential('TEST_CRED_ENV', 'test', 'Prompt: ')
            self.assertEqual(result, 'secret_from_env')
        finally:
            del os.environ['TEST_CRED_ENV']
    
    def test_environment_takes_priority_over_cli(self):
        import os
        import sys
        from imap_utils import get_credential
        
        os.environ['TEST_CRED_PRIO'] = 'from_env'
        original_argv = sys.argv
        sys.argv = ['prog', '--prio=from_cli']
        try:
            result = get_credential('TEST_CRED_PRIO', 'prio', 'Prompt: ')
            self.assertEqual(result, 'from_env')
        finally:
            del os.environ['TEST_CRED_PRIO']
            sys.argv = original_argv
    
    def test_reads_from_cli_with_equals(self):
        import os
        import sys
        from imap_utils import get_credential
        
        if 'TEST_CRED_CLI1' in os.environ:
            del os.environ['TEST_CRED_CLI1']
        
        original_argv = sys.argv
        sys.argv = ['prog', '--mycred=clivalue']
        try:
            result = get_credential('TEST_CRED_CLI1', 'mycred', 'Prompt: ')
            self.assertEqual(result, 'clivalue')
        finally:
            sys.argv = original_argv
    
    def test_reads_from_cli_with_space(self):
        import os
        import sys
        from imap_utils import get_credential
        
        if 'TEST_CRED_CLI2' in os.environ:
            del os.environ['TEST_CRED_CLI2']
        
        original_argv = sys.argv
        sys.argv = ['prog', '--mycred2', 'spacevalue']
        try:
            result = get_credential('TEST_CRED_CLI2', 'mycred2', 'Prompt: ')
            self.assertEqual(result, 'spacevalue')
        finally:
            sys.argv = original_argv


# ============================================================================
# proxy_utils.py tests
# ============================================================================

class TestProxyParseOptions(unittest.TestCase):
    """
    Tests for proxy option parsing.
    Uses realistic email addresses as they would appear in actual usage.
    """
    
    def _make_config(self):
        class Config:
            proxy_to = "81823@example.com"
            kindle_send_from = "kindle@example.com"
            kindle_send_to = "user@kindle.com"
            proxy_send_from = "proxy@example.com"
        return Config()
    
    def test_txt_option_converts_to_text(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"txt+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['as_txt'])
    
    def test_bleach_option_sanitizes_html(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"bleach+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['bleach_html'])
    
    def test_images_option_inlines_images(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"images+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['include_images'])
    
    def test_kindle_routes_to_kindle(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"kindle+txt+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['send_using_smtp'])
        self.assertEqual(opts['send_to'], config.kindle_send_to)
        self.assertEqual(opts['send_from'], config.kindle_send_from)
    
    def test_default_routes_back_to_sender(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"txt+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "original_sender@x")
        
        self.assertFalse(opts['send_using_smtp'])
        self.assertEqual(opts['send_to'], "original_sender@x")
    
    def test_combined_options(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"txt+bleach+images+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['as_txt'])
        self.assertTrue(opts['bleach_html'])
        self.assertTrue(opts['include_images'])
    
    def test_options_are_case_insensitive(self):
        from proxy_utils import proxy_parse_options
        config = self._make_config()
        to_addr = f"TXT+BLEACH+{config.proxy_to}"
        
        opts = proxy_parse_options(to_addr, config, "sender@x")
        
        self.assertTrue(opts['as_txt'])
        self.assertTrue(opts['bleach_html'])


class TestProxyDecodeTextContent(unittest.TestCase):
    """Tests for text content decoding"""
    
    def test_decodes_valid_utf8(self):
        from proxy_utils import proxy_decode_text_content
        
        result = proxy_decode_text_content("Héllo wörld".encode('utf-8'), 'utf-8')
        
        self.assertEqual(result, "Héllo wörld")
    
    def test_decodes_with_declared_charset(self):
        from proxy_utils import proxy_decode_text_content
        
        result = proxy_decode_text_content("Héllo".encode('iso-8859-1'), 'iso-8859-1')
        
        self.assertEqual(result, "Héllo")
    
    def test_handles_invalid_encoding_without_crashing(self):
        from proxy_utils import proxy_decode_text_content
        
        # Invalid bytes that may fail in some encodings
        content = bytes([0x80, 0x81, 0x82])
        
        result = proxy_decode_text_content(content, 'ascii')
        
        self.assertIsInstance(result, str)


class TestProxyFixFilenameExtension(unittest.TestCase):
    """Tests for filename extension handling"""
    
    def test_adds_txt_for_plain_text(self):
        from proxy_utils import proxy_fix_filename_extension
        
        result = proxy_fix_filename_extension("document", "plain")
        
        self.assertEqual(result, "document.txt")
    
    def test_adds_html_for_html(self):
        from proxy_utils import proxy_fix_filename_extension
        
        result = proxy_fix_filename_extension("page", "html")
        
        self.assertEqual(result, "page.html")
    
    def test_preserves_existing_correct_extension(self):
        from proxy_utils import proxy_fix_filename_extension
        
        result = proxy_fix_filename_extension("doc.txt", "plain")
        
        self.assertEqual(result, "doc.txt")
    
    def test_other_types_unchanged(self):
        from proxy_utils import proxy_fix_filename_extension
        
        result = proxy_fix_filename_extension("file.pdf", "pdf")
        
        self.assertEqual(result, "file.pdf")


if __name__ == "__main__":
    unittest.main(verbosity=2)
