# Test Coverage Analysis

Based on SPECIFICATION.md, analyzing `test_all.py` for exhaustiveness.

---

## Coverage Summary

| Module | Functions | Tested | Missing | Coverage |
|--------|-----------|--------|---------|----------|
| parsequery.py | 11 | 11 | 0 | ✅ 100% |
| http_utils.py | 6 | 2 | 4 | ⚠️ 33% |
| html_utils.py | 6 | 2 | 4 | ⚠️ 33% |
| email_utils.py | 11 | 6 | 5 | ⚠️ 55% |
| imap_utils.py | 5 | 0 | 5 | ❌ 0% |
| handlers.py | 17 | 0 | 17 | ❌ 0% |

---

## Detailed Analysis

### parsequery.py ✅ COMPLETE

| Function | Tested | Test Class |
|----------|--------|------------|
| `From/Froms` | ✅ | `TestFieldBuilders`, `TestPluralAliases` |
| `To/Tos` | ✅ | `TestFieldBuilders`, `TestPluralAliases` |
| `Cc/Ccs` | ✅ | `TestFieldBuilders`, `TestPluralAliases` |
| `Subject/SubjectPatterns` | ✅ | `TestFieldBuilders`, `TestPluralAliases` |
| `AnyOf` | ✅ | `TestCombinators` |
| `AllOf` | ✅ | `TestCombinators` |
| `Not` | ✅ | `TestCombinators` |
| `Match/parseQuery` | ✅ | `TestMatchFunction` |
| Nested expressions | ✅ | `TestNestedExpressions` |
| Real patterns | ✅ | `TestConfigQueriesPatterns` |
| IMAP syntax validity | ✅ | `TestIMAPSyntaxValidity` |
| Edge cases | ✅ | `TestEdgeCases` |

---

### http_utils.py ⚠️ PARTIAL

| Function | Tested | Notes |
|----------|--------|-------|
| `fetch_url` | ❌ | Requires network mocking |
| `fetch_and_decode_url` | ❌ | Requires network mocking |
| `get_filename_from_headers_or_url` | ✅ | `TestGetFilenameFromHeadersOrUrl` |
| `get_cached` | ❌ | Requires filesystem mocking |
| `store_cached` | ❌ | Requires filesystem mocking |
| `get_or_fetch` | ❌ | Requires both |

**Missing Tests**:
```python
class TestFetchUrl:
    def test_successful_fetch(self): ...
    def test_timeout_handling(self): ...
    def test_max_size_exceeded(self): ...
    def test_gzip_decompression(self): ...
    def test_deflate_decompression(self): ...
    def test_url_error_handling(self): ...

class TestCaching:
    def test_store_and_retrieve(self): ...
    def test_cache_miss_returns_none(self): ...
    def test_cache_directory_created(self): ...
```

---

### html_utils.py ⚠️ PARTIAL

| Function | Tested | Notes |
|----------|--------|-------|
| `make_html2text_converter` | ✅ | `TestMakeHtml2TextConverter` |
| `bleach_content` | ❌ | Requires lxml |
| `include_images_in_tree` | ❌ | Requires lxml + network mocking |
| `transform_html_content` | ✅ | `TestTransformHtmlContent` (basic) |
| `deobfuscate_spiegel` | ❌ | |
| `apply_deobfuscation` | ❌ | |

**Missing Tests**:
```python
class TestBleachContent:
    def test_removes_scripts(self): ...
    def test_removes_javascript(self): ...
    def test_removes_forms(self): ...
    def test_preserves_safe_attrs(self): ...
    def test_applies_deobfuscator(self): ...

class TestIncludeImagesInTree:
    def test_inlines_large_images(self): ...
    def test_drops_small_images(self): ...
    def test_respects_max_images(self): ...
    def test_handles_fetch_failure(self): ...
    def test_uses_cache(self): ...

class TestDeobfuscateSpiegel:
    def test_shifts_characters(self): ...
    def test_handles_nested_elements(self): ...

class TestTransformHtmlContent:
    def test_bleach_option(self): ...
    def test_images_option(self): ...
    def test_txt_with_links(self): ...
    def test_txt_without_links(self): ...
    def test_prefix_generation(self): ...
```

---

### email_utils.py ⚠️ PARTIAL

| Function | Tested | Notes |
|----------|--------|-------|
| `should_process_message` | ✅ | `TestShouldProcessMessage` |
| `detect_language` | ✅ | `TestDetectLanguage` |
| `create_email_message` | ❌ | |
| `create_reply_message` | ❌ | |
| `create_forward_message` | ❌ | |
| `build_mime_parts` | ✅ | `TestBuildMimeParts` |
| `send_via_smtp` | ❌ | Requires SMTP mocking |
| `_decode_part` | ✅ | `TestDecodePart` |
| `extract_urls_from_email` | ❌ | |
| `get_decoded_email_body` | ❌ | |

**Missing Tests**:
```python
class TestCreateEmailMessage:
    def test_basic_headers(self): ...
    def test_reply_to_header(self): ...
    def test_in_reply_to_references(self): ...
    def test_message_id_generation(self): ...
    def test_subject_prefix(self): ...

class TestCreateReplyMessage:
    def test_re_prefix_added(self): ...
    def test_body_attached(self): ...
    def test_inherits_headers(self): ...

class TestCreateForwardMessage:
    def test_fwd_prefix_added(self): ...
    def test_original_attached(self): ...
    def test_forward_note_included(self): ...

class TestSendViaSmtp:
    def test_successful_send(self): ...
    def test_connection_cleanup(self): ...
    def test_accepts_string_message(self): ...
    def test_accepts_message_object(self): ...

class TestExtractUrlsFromEmail:
    def test_extracts_from_plain_text(self): ...
    def test_extracts_from_html(self): ...
    def test_deduplicates_urls(self): ...
    def test_handles_multipart(self): ...
    def test_handles_missing_parts(self): ...

class TestGetDecodedEmailBody:
    def test_prefers_plain_text(self): ...
    def test_falls_back_to_html(self): ...
    def test_handles_non_multipart(self): ...
    def test_returns_empty_on_failure(self): ...

class TestDetectLanguage:
    def test_content_language_header(self): ✅
    def test_german_subject_keywords(self): ✅
    def test_default_fallback(self): ✅
    def test_other_languages(self): ...  # MISSING
```

---

### imap_utils.py ❌ NO TESTS

| Function | Tested | Notes |
|----------|--------|-------|
| `get_credential` | ❌ | Needs env/argv/stdin mocking |
| `idle` | ❌ | Needs IMAP mocking |
| `connect_and_select` | ❌ | Needs IMAP mocking |
| `disconnect` | ❌ | Needs IMAP mocking |
| `run` | ❌ | Integration test |

**Missing Tests**:
```python
class TestGetCredential:
    def test_from_environment(self): ...
    def test_from_cli_equals(self): ...
    def test_from_cli_space(self): ...
    def test_from_prompt(self): ...
    def test_priority_env_over_cli(self): ...

class TestIdle:
    def test_sends_idle_command(self): ...
    def test_waits_for_response(self): ...
    def test_sends_done_on_timeout(self): ...
    def test_raises_if_not_supported(self): ...

class TestConnectAndSelect:
    def test_connects_ssl(self): ...
    def test_logs_in(self): ...
    def test_selects_inbox(self): ...

class TestRun:
    def test_once_mode_exits(self): ...
    def test_reconnect_on_failure(self): ...
    def test_exponential_backoff(self): ...
    def test_keyboard_interrupt(self): ...
```

---

### handlers.py ❌ NO TESTS

| Function | Tested | Notes |
|----------|--------|-------|
| `Expunge` | ❌ | |
| `Delete` | ❌ | |
| `Copy` | ❌ | |
| `Move` | ❌ | |
| `SetFlags` | ❌ | |
| `SetFlagsAndMove` | ❌ | |
| `WorkEmail` | ❌ | Complex: IMAP + SMTP |
| `Obnoxious` | ❌ | Complex: IMAP + SMTP |
| `Proxy` | ❌ | Complex: IMAP + HTTP + SMTP |
| `_process_proxy_email` | ❌ | |
| `_parse_proxy_options` | ❌ | Pure function, easy to test |
| `_extract_urls` | ❌ | |
| `_fetch_and_store_url` | ❌ | |
| `_build_message_from_url` | ❌ | |
| `_decode_text_content` | ❌ | Pure function, easy to test |
| `_fix_filename_extension` | ❌ | Pure function, easy to test |
| `runQueries` | ❌ | Integration test |

**Missing Tests**:
```python
class TestSimpleHandlers:
    def test_expunge_calls_server(self): ...
    def test_delete_marks_deleted(self): ...
    def test_copy_to_folder(self): ...
    def test_move_copies_then_deletes(self): ...
    def test_set_flags(self): ...
    def test_handlers_return_seen_ids(self): ...

class TestParseProxyOptions:
    def test_txt_option(self): ...
    def test_bleach_option(self): ...
    def test_images_option(self): ...
    def test_wolinks_option(self): ...
    def test_inline_option(self): ...
    def test_kindle_routing(self): ...
    def test_default_routing(self): ...
    def test_case_insensitive(self): ...

class TestDecodeTextContent:
    def test_declared_charset(self): ...
    def test_fallback_to_utf8(self): ...
    def test_fallback_to_latin1(self): ...
    def test_replace_errors(self): ...
    def test_normalizes_newlines(self): ...

class TestFixFilenameExtension:
    def test_adds_txt_extension(self): ...
    def test_adds_html_extension(self): ...
    def test_preserves_existing_extension(self): ...

class TestWorkEmail:
    def test_sends_reply(self): ...
    def test_sends_forward(self): ...
    def test_detects_language(self): ...
    def test_deduplication(self): ...
    def test_smtp_failure_logged(self): ...
    def test_forward_before_reply(self): ...

class TestObnoxious:
    def test_deletes_first(self): ...
    def test_sends_reply(self): ...
    def test_deduplication(self): ...

class TestProxy:
    def test_extracts_urls(self): ...
    def test_fetches_and_stores(self): ...
    def test_kindle_routing(self): ...
    def test_url_fetch_failure_continues(self): ...

class TestRunQueries:
    def test_executes_matching_handlers(self): ...
    def test_two_cycle_dedup(self): ...
    def test_idle_loop(self): ...
```

---

## Priority Recommendations

### High Priority (Pure functions, easy wins)

1. **`_parse_proxy_options`** - Pure function, no mocking needed
2. **`_decode_text_content`** - Pure function, no mocking needed  
3. **`_fix_filename_extension`** - Pure function, no mocking needed
4. **`get_credential`** - Can mock `os.environ` and `sys.argv`
5. **`create_email_message`** - Returns object, easy to inspect

### Medium Priority (Need simple mocking)

6. **`extract_urls_from_email`** - Need to construct test emails
7. **`get_decoded_email_body`** - Need to construct test emails
8. **Simple handlers** - Mock IMAP server object
9. **Caching functions** - Mock filesystem

### Low Priority (Integration tests, complex mocking)

10. **`WorkEmail`, `Obnoxious`, `Proxy`** - Need IMAP + SMTP mocking
11. **`fetch_url`** - Need HTTP mocking
12. **`runQueries`** - Full integration test
13. **`run`** - Full integration test

---

## Suggested Test Structure

```
test_all.py              # Existing tests (parsequery focus)
test_http_utils.py       # HTTP and caching tests
test_html_utils.py       # HTML transformation tests
test_email_utils.py      # Email parsing/construction tests
test_imap_utils.py       # IMAP protocol tests
test_handlers.py         # Handler tests
test_integration.py      # End-to-end tests
```

---

## Quick Wins: Tests to Add Immediately

```python
# Add to test_all.py - no external dependencies needed

class TestParseProxyOptions(unittest.TestCase):
    def test_txt_option(self):
        from handlers import _parse_proxy_options
        
        class Config:
            kindle_send_from = "k@x"
            kindle_send_to = "k@y"
            proxy_send_from = "p@x"
        
        opts = _parse_proxy_options("txt@proxy.com", Config(), "sender@x")
        self.assertTrue(opts['as_txt'])
        self.assertFalse(opts['bleach_html'])
    
    def test_kindle_routing(self):
        from handlers import _parse_proxy_options
        
        class Config:
            kindle_send_from = "k@x"
            kindle_send_to = "k@y"
            proxy_send_from = "p@x"
        
        opts = _parse_proxy_options("kindle@proxy.com", Config(), "sender@x")
        self.assertTrue(opts['send_using_smtp'])
        self.assertEqual(opts['send_to'], "k@y")
    
    def test_case_insensitive(self):
        from handlers import _parse_proxy_options
        
        class Config:
            kindle_send_from = "k@x"
            kindle_send_to = "k@y"
            proxy_send_from = "p@x"
        
        opts = _parse_proxy_options("TXT+BLEACH@proxy.com", Config(), "sender@x")
        self.assertTrue(opts['as_txt'])
        self.assertTrue(opts['bleach_html'])


class TestDecodeTextContent(unittest.TestCase):
    def test_utf8_decode(self):
        from handlers import _decode_text_content
        result = _decode_text_content("Hello".encode('utf-8'), 'utf-8')
        self.assertEqual(result, "Hello")
    
    def test_normalizes_crlf(self):
        from handlers import _decode_text_content
        result = _decode_text_content(b"a\r\nb\r\nc", 'utf-8')
        self.assertEqual(result, "a\nb\nc")
    
    def test_fallback_to_latin1(self):
        from handlers import _decode_text_content
        # Bytes that are invalid UTF-8 but valid Latin-1
        content = bytes([0xe4, 0xf6, 0xfc])  # äöü in Latin-1
        result = _decode_text_content(content, 'utf-8')
        self.assertIn('ä', result)


class TestFixFilenameExtension(unittest.TestCase):
    def test_adds_txt(self):
        from handlers import _fix_filename_extension
        self.assertEqual(_fix_filename_extension("doc", "plain"), "doc.txt")
    
    def test_adds_html(self):
        from handlers import _fix_filename_extension
        self.assertEqual(_fix_filename_extension("page", "html"), "page.html")
    
    def test_preserves_txt(self):
        from handlers import _fix_filename_extension
        self.assertEqual(_fix_filename_extension("doc.txt", "plain"), "doc.txt")
    
    def test_other_subtype_unchanged(self):
        from handlers import _fix_filename_extension
        self.assertEqual(_fix_filename_extension("file.pdf", "pdf"), "file.pdf")


class TestCreateEmailMessage(unittest.TestCase):
    def test_basic_headers(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x"
        )
        self.assertEqual(msg['Subject'], "Test")
        self.assertEqual(msg['From'], "from@x")
        self.assertEqual(msg['To'], "to@x")
        self.assertIsNotNone(msg['Message-ID'])
        self.assertIsNotNone(msg['Date'])
    
    def test_subject_prefix(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            subject_prefix="Re:"
        )
        self.assertEqual(msg['Subject'], "Re: Test")
    
    def test_reply_headers(self):
        from email_utils import create_email_message
        msg = create_email_message(
            subject="Test",
            from_addr="from@x",
            to_addr="to@x",
            in_reply_to="<original@x>"
        )
        self.assertEqual(msg['In-Reply-To'], "<original@x>")
        self.assertEqual(msg['References'], "<original@x>")
```
