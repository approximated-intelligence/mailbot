# Email Proxy System Specification

## Overview

An IMAP-based email automation system that monitors an inbox and applies rule-based processing to incoming emails. Runs as a daemon using IMAP IDLE for efficient real-time processing.

---

## Architecture

### Modules

| Module | Responsibility |
|--------|----------------|
| `config_data.py` | Pure configuration data (servers, addresses, templates) |
| `config_queries.py` | Query-handler wiring (what rules trigger what actions) |
| `parsequery.py` | DSL for constructing IMAP SEARCH queries |
| `http_utils.py` | HTTP fetching, caching |
| `html_utils.py` | HTML sanitization, transformation, text extraction |
| `email_utils.py` | Email parsing, construction, SMTP sending |
| `imap_utils.py` | IMAP protocol (IDLE, connection management) |
| `handlers.py` | Email processing handlers |
| `runloop.py` | Daemon entry point |
| `runonce.py` | Single-run entry point |

### Data Flow

```
IMAP Inbox
    ↓
imap_utils.idle() detects change
    ↓
handlers.runQueries() executes query loop
    ↓
For each query in config_queries.Queries:
    ├── parsequery.Match() → IMAP SEARCH string
    ├── IMAP UID SEARCH → list of matching UIDs
    └── For each handler in handler chain:
            handler(server, uids, options, seen_ids) → (res, data, seen_ids)
    ↓
Loop continues until connection fails or KeyboardInterrupt
```

---

## Component Specifications

### 1. parsequery.py - Query DSL

**Purpose**: Convert composable S-expressions to IMAP SEARCH syntax.

**Functions**:

| Function | Input | Output | Description |
|----------|-------|--------|-------------|
| `Froms(*addrs)` | Variable addresses | List of thunks | Creates FROM matchers |
| `Tos(*addrs)` | Variable addresses | List of thunks | Creates TO matchers |
| `Ccs(*addrs)` | Variable addresses | List of thunks | Creates CC matchers |
| `SubjectPatterns(*patterns)` | Variable patterns | List of thunks | Creates SUBJECT matchers |
| `AnyOf(*matchers)` | Matcher lists | Single-item list | OR combination |
| `AllOf(*matchers)` | Matcher lists | Single-item list | AND combination |
| `Not(*matchers)` | Matcher lists | Single-item list | Negation |
| `Match(expr)` | Expression list | IMAP SEARCH string | Evaluates expression |

**Aliases**: `From=Froms`, `To=Tos`, `Cc=Ccs`, `Subject=SubjectPatterns`

**IMAP Behavior**: Case-insensitive substring matching (per RFC 3501).

---

### 2. http_utils.py - HTTP Utilities

**Purpose**: Fetch URLs with caching support.

**Functions**:

| Function | Input | Output | Description |
|----------|-------|--------|-------------|
| `fetch_url(url, timeout, max_size)` | URL, timeout seconds, max bytes | (content, base_href, headers, info) | Fetch with size limit |
| `fetch_and_decode_url(url, timeout, max_size)` | URL, timeout, max bytes | (content, base_href, headers, info, mimetype, subtype) | Fetch + parse content-type |
| `get_filename_from_headers_or_url(headers, url)` | Headers dict, URL | Filename string | Extract filename |
| `get_cached(url)` | URL | Bytes or None | Check cache |
| `store_cached(url, content)` | URL, content bytes | None | Store in cache |
| `get_or_fetch(url, timeout)` | URL, timeout | Bytes | Cache-through fetch |

**Caching**: SHA256 hash of URL as filename in `config.cache_prefix` directory.

**Compression**: Automatic gzip/deflate decompression.

---

### 3. html_utils.py - HTML Utilities

**Purpose**: Transform HTML content for email delivery.

**Functions**:

| Function | Input | Output | Description |
|----------|-------|--------|-------------|
| `make_html2text_converter()` | None | html2text instance | Configured converter |
| `bleach_content(tree, base_href, deobfuscators)` | lxml tree, URL, deobfuscator map | Cleaned tree | Remove dangerous elements |
| `include_images_in_tree(tree, timeout, max_images)` | lxml tree, timeout, limit | Tree with inlined images | Base64 data URIs |
| `transform_html_content(tree, base_href, config, bleach, images, txt, no_links)` | Tree + options | (content, title, subtype, prefix) | Full transformation pipeline |
| `deobfuscate_spiegel(tree)` | lxml tree | Deobfuscated tree | Site-specific fix |
| `apply_deobfuscation(tree, url, deobfuscators)` | Tree, URL, map | Tree | Apply matching deobfuscator |

**Transformation Prefix Codes**:
- `B` = bleached
- `I` = images inlined
- `TL` = text with links
- `TP` = text plain (no links)

---

### 4. email_utils.py - Email Utilities

**Purpose**: Email parsing, construction, and sending.

**Functions**:

| Function | Input | Output | Description |
|----------|-------|--------|-------------|
| `should_process_message(message_id, seen_ids)` | Message-ID, set | (bool, updated_set) | Deduplication check |
| `detect_language(email_message, available_languages, default)` | Email, lang list, default | Language code | Detect from headers/subject |
| `create_email_message(subject, from, to, in_reply_to, reply_to, prefix, domain)` | Headers | MIMEMultipart | Base message construction |
| `create_reply_message(subject, from, to, in_reply_to, body, reply_to, domain)` | Fields | Complete reply | Reply with Re: prefix |
| `create_forward_message(subject, from, to, in_reply_to, note, original, reply_to)` | Fields | Complete forward | Forward with Fwd: prefix |
| `build_mime_parts(content, mimetype, subtype, filename, subject, charset, inline, info)` | Content + metadata | List of MIME parts | Build attachments |
| `send_via_smtp(options, from, to, message)` | SMTP config, addresses, message | None | Send email |
| `_decode_part(part)` | MIME part | String or None | Decode with charset fallback |
| `extract_urls_from_email(msg)` | Email message | Set of URLs | Extract all URLs |
| `get_decoded_email_body(msg)` | Email message | Body string | Best-effort body extraction |

**Charset Fallback Order**: declared charset → UTF-8 → ISO-8859-1 → UTF-8 with replacement.

---

### 5. imap_utils.py - IMAP Utilities

**Purpose**: IMAP protocol operations.

**Functions**:

| Function | Input | Output | Description |
|----------|-------|--------|-------------|
| `get_credential(env_var, arg_name, prompt)` | Env var name, CLI arg, prompt | String | Get password from env/CLI/stdin |
| `idle(connection, timeout)` | IMAP connection, seconds | (typ, responses) | RFC 2177 IDLE |
| `connect_and_select(config, password)` | Config module, password | IMAP connection | Connect and select inbox |
| `disconnect(connection)` | IMAP connection | None | Clean close |
| `run(config, queries, handler_module, password, once, initial_delay, max_delay)` | All config | None | Main run loop |

**Credential Priority**: Environment variable → `--arg=value` → `--arg value` → interactive prompt.

**Reconnection**: Exponential backoff from `initial_delay` to `max_delay`.

---

### 6. handlers.py - Email Handlers

**Purpose**: Process emails matching queries.

**Handler Interface**: `handler(server, listofuids, options, seen_ids) → (res, data, seen_ids)`

**Handlers**:

| Handler | Parameters | Actions | Side Effects |
|---------|------------|---------|--------------|
| `Expunge()` | None | Remove deleted messages | IMAP expunge |
| `Delete()` | None | Mark messages deleted | IMAP flag |
| `Copy(folder)` | Target folder | Copy messages | IMAP copy |
| `Move(folder)` | Target folder | Copy + delete | IMAP copy + flag |
| `SetFlags(flag)` | IMAP flag | Set flag on messages | IMAP flag |
| `SetFlagsAndMove(flag, folder)` | Flag, folder | Set flag + move | Combined |
| `WorkEmail(config)` | Config module | Auto-reply + forward | SMTP × 2 |
| `Obnoxious(config)` | Config module | Delete + snarky reply | IMAP delete + SMTP |
| `Proxy(config)` | Config module | Fetch URLs, store as email | HTTP fetch + IMAP append |

**Helper Functions** (Proxy decomposition):
- `_process_proxy_email(ret, server, options, seen_ids, config)`
- `_parse_proxy_options(to_addr, config, sender)`
- `_extract_urls(themail, subject)`
- `_fetch_and_store_url(url, subject, ref_mid, proxy_options, server, options, config)`
- `_build_message_from_url(url, subject, ref_mid, proxy_options, config)`
- `_decode_text_content(content, charset)`
- `_fix_filename_extension(filename, subtype)`

**Query Runner**:
- `runQueries(connection, queries, runtime_options)` - Main IDLE loop

**Deduplication**: Two-cycle `seen_ids` window prevents duplicate processing when emails arrive via BCC within seconds.

---

### 7. Proxy Handler Options

Triggered by substrings in the To address:

| Substring | Effect |
|-----------|--------|
| `txt` | Convert HTML to plain text |
| `bleach` | Sanitize HTML |
| `images` | Inline images as base64 |
| `wolinks` | Plain text without links |
| `inline` | Content inline (not attachment) |
| `kindle` | Send via SMTP to Kindle address |

---

## Error Handling

| Scenario | Behavior |
|----------|----------|
| IMAP connection failure | Reconnect with exponential backoff |
| SMTP failure (WorkEmail) | Log error, continue (forward first, reply second) |
| SMTP failure (Obnoxious) | Log error, email already deleted |
| URL fetch failure (Proxy) | Log error, continue to next URL |
| Charset decode failure | Fallback chain, ultimately replace errors |
| KeyboardInterrupt | Graceful shutdown |
| SystemExit | Propagate |

---

## Configuration Requirements

Required in `config_data.py`:

```python
# Server
imap_server: str
imap_user: str
inbox: str
smtp_server: str
smtp_user: str

# Identity
mydomain: str

# Caching
cache_prefix: str

# Timeouts
default_fetch_timeout: int
default_max_download_size: int
default_image_timeout: int
default_max_images: int

# Deobfuscators
deobfuscators: dict[str, str]

# Work email
work_senders: list[str]
work_reply_from: str
work_forward_by: str
work_forward_to: str
work_reply: dict[str, str]
work_forward_note: dict[str, str]

# Newsletters
newsletters: list[str]

# For the record
for_the_record_only: list[str]

# Obnoxious
obnoxious_senders: list[str]
obnoxious_reply_from: str
obnoxious_reply: dict[str, str]

# Proxy
proxy_to: str
proxy_send_from: str
proxy_store_to: str
kindle_send_from: str
kindle_send_to: str
```

---

## Security Considerations

1. **Credentials**: Never stored in code; sourced from environment/CLI/prompt
2. **HTML sanitization**: `bleach_content` removes scripts, forms, dangerous elements
3. **URL fetching**: Size limits prevent memory exhaustion
4. **No external code execution**: Deobfuscators are hardcoded function references
5. **SMTP authentication**: Required for all sends

---

## Testing Requirements

See "Test Coverage Analysis" section below.
